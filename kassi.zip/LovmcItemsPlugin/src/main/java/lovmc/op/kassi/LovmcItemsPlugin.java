package lovmc.op.kassi;

import com.google.common.base.MoreObjects;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.util.ArrayList;
import java.util.List;

import static org.bukkit.enchantments.Enchantment.*;

public final class LovmcItemsPlugin extends JavaPlugin implements Listener {

    private Objective objective;
    private ScoreboardManager manager;
    private Scoreboard board;

    @Override
    public void onEnable() {
        // Plugin startup logic

        Bukkit.getServer().getPluginManager().registerEvents(this,this);

        getLogger().info("Lovmcアイテムプラグインは有効です。");
        manager = Bukkit.getScoreboardManager();
        board = manager.getNewScoreboard();
        objective = board.getObjective("check");
        if (objective == null) {
            objective = board.registerNewObjective("check", "dummy");
        }

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        getLogger().info("Lovmcアイテムプラグインは無効です。");
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event){
        Player player = event.getPlayer();

        //getLogger().info("bad");

        ItemStack item = player.getInventory().getItemInMainHand();

        if (item.hasItemMeta()) {

            ItemMeta meta = item.getItemMeta();

            //getLogger().info("good");

            if (meta.getCustomModelData() == 3939393){

                if ((event.getAction() == Action.RIGHT_CLICK_AIR) || (event.getAction() == Action.LEFT_CLICK_AIR) || (event.getAction() == Action.LEFT_CLICK_BLOCK)) {

                    //Command /m
                    //getLogger().info("great");
                    Bukkit.dispatchCommand(player, "commandpanel menu");
                }
            }
        }
    }

    @EventHandler
    public void onPlayerJoin (PlayerJoinEvent event){

        Player player = event.getPlayer();

        // --------------------------------------

        player.setResourcePack("https://drive.google.com/uc?id=1tFncZkLE9We-ZKZHu7m-i5er9SEVBnwi");//DirectDownload
        // --------------------------------------

        //objective = board.getObjective("check");
        Score score = objective.getScore(player.getName());

        //getLogger().info("score is " + score.getScore());

        if ((score == null)||(score.getScore() == 0)) {

            Inventory inv = player.getInventory();
            //getLogger().info("test2");

            if(inv.firstEmpty() != -1){

                //getLogger().info("test");

                ItemStack item = new ItemStack(Material.BOOK,1);
                ItemMeta meta = item.getItemMeta();
                meta.setCustomModelData(3939393);
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&b&l=== &9&lL&5&lO&6&lV&3&lM&9&lC&d&l Phone &b&l==="));
                meta.addEnchant(LUCK,10,true);
                List<String> lores = new ArrayList<String>();
                lores.add("右クリックでメニューを開けます。");
                lores.add("Right click to open the menu");
                meta.setLore(lores);
                item.setItemMeta(meta);
                inv.addItem(item);

                score.setScore(1);
            }

        }
    }

    //@Override

    //public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args){

        //Player player = null;
        //if (sender instanceof Player){
            //player = (Player) sender;
        //}else{
            //sender.sendMessage("プレイヤーしか使用できないコマンドです。");
            //sender.sendMessage("this command is only used by player.");
            //return true;
        //}

        //if(cmd.getName().equalsIgnoreCase("resetjoindata")) {

            //objective = board.getObjective("check");
            //Score score = objective.getScore(player.getName());
            //score.setScore(0);
            //sender.sendMessage(player.getName() + " reset his join data");
            //sender.sendMessage(player.getName() + " join data is " + score.getScore());
            //return true;
        //}

        //if(cmd.getName().equalsIgnoreCase("getsmartphone")) {

            //Inventory inv = player.getInventory();

            //ItemStack item = new ItemStack(Material.BOOK,1);
            //ItemMeta meta = item.getItemMeta();
            //meta.setCustomModelData(3939393);
            //meta.setDisplayName(ChatColor.GOLD + "LovmcSmartphone");
            //meta.addEnchant(LUCK,10,true);
            //List<String> lores = new ArrayList<String>();
            //lores.add("右クリックでメニューを開けます。");
            //lores.add("Right click to open the menu");
            //meta.setLore(lores);
            //item.setItemMeta(meta);
            //inv.addItem(item);
        //}

        //return false;
    //}


}
